import "./AspectRatio.scss";
const { defineProps, defineSlots, defineEmits, defineExpose, defineModel, defineOptions, withDefaults, } = await import('vue');
const __VLS_props = defineProps({
    /**
     * Wanted ratio
     */
    ratio: {
        type: Number,
        default: () => 100
    }
});
const __VLS_fnComponent = (await import('vue')).defineComponent({
    props: {
        /**
         * Wanted ratio
         */
        ratio: {
            type: Number,
            default: () => 100
        }
    },
});
;
let __VLS_functionalComponentProps;
function __VLS_template() {
    const __VLS_ctx = {};
    const __VLS_localComponents = {
        ...{},
        ...{},
        ...__VLS_ctx,
    };
    let __VLS_components;
    const __VLS_localDirectives = {
        ...{},
        ...__VLS_ctx,
    };
    let __VLS_directives;
    let __VLS_styleScopedClasses;
    let __VLS_resolvedLocalAndGlobalComponents;
    __VLS_elementAsFunction(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({ ...{ class: ("aspect-ratio-component") }, ...{ style: (({
                '--aspect-ratio': __VLS_ctx.ratio + '%'
            })) }, });
    var __VLS_0 = {};
    __VLS_styleScopedClasses['aspect-ratio-component'];
    var __VLS_slots;
    var __VLS_inheritedAttrs;
    const __VLS_refs = {};
    var $refs;
    return {
        slots: __VLS_slots,
        refs: $refs,
        attrs: {},
    };
}
;
const __VLS_self = (await import('vue')).defineComponent({
    setup() {
        return {};
    },
    props: {
        /**
         * Wanted ratio
         */
        ratio: {
            type: Number,
            default: () => 100
        }
    },
});
const __VLS_component = (await import('vue')).defineComponent({
    setup() {
        return {};
    },
    props: {
        /**
         * Wanted ratio
         */
        ratio: {
            type: Number,
            default: () => 100
        }
    },
});
export default {};
;
