import "./Media.scss";
const { defineProps, defineSlots, defineEmits, defineExpose, defineModel, defineOptions, withDefaults, } = await import('vue');
const props = defineProps({
    /**
     * url/path to media
     */
    media: {
        type: String,
        required: true
    },
    /**
     * Background type
     * Background can be an image, a video, an iframe or a color
     * In case of VIDEO, the type is the codec (es: mp4)
     * In case of CSS, it an image that will be used on background-image
     */
    type: {
        type: String,
        default: () => 'image'
    },
    /**
     * When height & width are fixed
     */
    height: {
        type: String,
        required: false
    },
    width: {
        type: String,
        required: false
    },
    /**
     * If the thumbnail and lazy are set,
     * we are gonna use the thumbnail and lazyload the correct media later
     *
     * If lazyload is set but thumbnail not: native lazyload (image only)
     *
     * Otherwise, it's the video's poster
     */
    thumbnail: {
        type: String,
        required: false
    },
    /**
     * Activate lazyload.
     */
    lazy: {
        type: Boolean,
        default: () => false
    },
    /**
     * Class that will be set after
     * a successful lazyload
     */
    loadedClass: {
        type: String,
        default: () => 'loaded'
    },
    /**
     * TODO ratio of media
     * (if only 1 or less fixed width/height)
     */
    ratio: {
        type: String,
        required: false
    },
    /**
     * Title TAG
     */
    title: {
        type: String,
        default: () => ''
    },
    /**
     * Alt TAG
     */
    alt: {
        type: String,
        default: () => ''
    }
});
/**
 *
 * @param el
 * @param intersectCallback
 */
function _observerHelper(el, intersectCallback) {
    if (!props.lazy || !el)
        return;
    const observer = new IntersectionObserver(entries => {
        if (!entries[0].isIntersecting)
            return;
        intersectCallback(entries[0].target);
        // one time only
        observer.disconnect();
    });
    // observe
    observer.observe(el);
}
/**
 *
 * @param el
 */
function setImageRef(el) {
    _observerHelper(el, (target) => {
        target.src = props.media;
        target.classList.add(props.loadedClass);
    });
}
/**
 *
 * @param el
 */
function setCssRef(el) {
    _observerHelper(el, (target) => {
        target.style.backgroundImage = 'url(\'' + props.media + '\')';
        target.classList.add(props.loadedClass);
    });
}
/**
 *
 * @param el
 */
function setIframeRef(el) {
    _observerHelper(el, (target) => {
        target.src = props.media;
        target.classList.add(props.loadedClass);
    });
}
/**
 *
 * @param el
 */
function setVideoRef(el) {
    _observerHelper(el, (target) => {
        // targets
        const video = target;
        const source = target.firstElementChild;
        // video UI check
        if ((video.currentTime > 0 && !video.paused && !video.ended && video.readyState > 2) ||
            window.matchMedia('(prefers-reduced-motion: reduce)').matches)
            return;
        // set the true image
        source.src = props.media;
        video.onloadeddata = function () {
            this.classList.add(props.loadedClass);
        };
        video.load();
    });
}
const __VLS_fnComponent = (await import('vue')).defineComponent({
    props: {
        /**
         * url/path to media
         */
        media: {
            type: String,
            required: true
        },
        /**
         * Background type
         * Background can be an image, a video, an iframe or a color
         * In case of VIDEO, the type is the codec (es: mp4)
         * In case of CSS, it an image that will be used on background-image
         */
        type: {
            type: String,
            default: () => 'image'
        },
        /**
         * When height & width are fixed
         */
        height: {
            type: String,
            required: false
        },
        width: {
            type: String,
            required: false
        },
        /**
         * If the thumbnail and lazy are set,
         * we are gonna use the thumbnail and lazyload the correct media later
         *
         * If lazyload is set but thumbnail not: native lazyload (image only)
         *
         * Otherwise, it's the video's poster
         */
        thumbnail: {
            type: String,
            required: false
        },
        /**
         * Activate lazyload.
         */
        lazy: {
            type: Boolean,
            default: () => false
        },
        /**
         * Class that will be set after
         * a successful lazyload
         */
        loadedClass: {
            type: String,
            default: () => 'loaded'
        },
        /**
         * TODO ratio of media
         * (if only 1 or less fixed width/height)
         */
        ratio: {
            type: String,
            required: false
        },
        /**
         * Title TAG
         */
        title: {
            type: String,
            default: () => ''
        },
        /**
         * Alt TAG
         */
        alt: {
            type: String,
            default: () => ''
        }
    },
});
;
let __VLS_functionalComponentProps;
function __VLS_template() {
    const __VLS_ctx = {};
    const __VLS_localComponents = {
        ...{},
        ...{},
        ...__VLS_ctx,
    };
    let __VLS_components;
    const __VLS_localDirectives = {
        ...{},
        ...__VLS_ctx,
    };
    let __VLS_directives;
    let __VLS_styleScopedClasses;
    let __VLS_resolvedLocalAndGlobalComponents;
    if (__VLS_ctx.type === 'image') {
        var __VLS_0 = {};
        __VLS_elementAsFunction(__VLS_intrinsicElements.img, __VLS_intrinsicElements.img)({ ref: ((__VLS_ctx.setImageRef)), src: ((__VLS_ctx.lazy ? __VLS_ctx.thumbnail : __VLS_ctx.media)), alt: ((__VLS_ctx.alt)), title: ((__VLS_ctx.title)), lazyload: ((__VLS_ctx.lazy && !__VLS_ctx.thumbnail)), ...{ style: (({
                    height: __VLS_ctx.height,
                    width: __VLS_ctx.width,
                })) }, ...(__VLS_ctx.$attrs), });
    }
    else if (__VLS_ctx.type === 'color') {
        var __VLS_1 = {};
        __VLS_elementAsFunction(__VLS_intrinsicElements.div)({ ...{ style: (({
                    'background-color': __VLS_ctx.media,
                    height: __VLS_ctx.height,
                    width: __VLS_ctx.width
                })) }, ...(__VLS_ctx.$attrs), });
    }
    else if (__VLS_ctx.type === 'css') {
        var __VLS_2 = {};
        __VLS_elementAsFunction(__VLS_intrinsicElements.div)({ ref: ((__VLS_ctx.setCssRef)), ...{ style: (({
                    'background-image': __VLS_ctx.lazy && __VLS_ctx.thumbnail ? 'url(\'' + __VLS_ctx.thumbnail + '\')' : 'url(\'' + __VLS_ctx.media + '\')',
                    'background-repeat': 'no-repeat',
                    'background-position': 'center',
                    'background-size': 'cover',
                    height: __VLS_ctx.height,
                    width: __VLS_ctx.width
                })) }, "aria-label": ((__VLS_ctx.title)), "aria-details": ((__VLS_ctx.alt)), ...(__VLS_ctx.$attrs), });
    }
    else if (__VLS_ctx.type === 'iframe') {
        var __VLS_3 = {};
        __VLS_elementAsFunction(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({ ...{ style: (({
                    position: 'relative',
                    height: __VLS_ctx.height,
                    width: __VLS_ctx.width
                })) }, ...(__VLS_ctx.$attrs), });
        __VLS_elementAsFunction(__VLS_intrinsicElements.iframe)({ ref: ((__VLS_ctx.setIframeRef)), src: ((__VLS_ctx.lazy ? undefined : __VLS_ctx.media)), frameborder: ("0"), allowfullscreen: (true), title: ((__VLS_ctx.title)), });
    }
    else {
        var __VLS_4 = {};
        __VLS_elementAsFunction(__VLS_intrinsicElements.video, __VLS_intrinsicElements.video)({ ref: ((__VLS_ctx.setVideoRef)), ...{ style: (({
                    height: __VLS_ctx.height,
                    width: __VLS_ctx.width
                })) }, preload: ("metadata"), playsinline: (true), muted: (true), loop: (true), autoplay: (true), poster: ((__VLS_ctx.thumbnail)), alt: ((__VLS_ctx.alt)), title: ((__VLS_ctx.title)), ...(__VLS_ctx.$attrs), });
        __VLS_elementAsFunction(__VLS_intrinsicElements.source, __VLS_intrinsicElements.source)({ src: ((__VLS_ctx.lazy ? undefined : __VLS_ctx.media)), type: ((__VLS_ctx.type)), });
    }
    var __VLS_slots;
    var __VLS_inheritedAttrs;
    const __VLS_refs = {};
    var $refs;
    return {
        slots: __VLS_slots,
        refs: $refs,
        attrs: {},
    };
}
;
const __VLS_self = (await import('vue')).defineComponent({
    setup() {
        return {
            setImageRef: setImageRef,
            setCssRef: setCssRef,
            setIframeRef: setIframeRef,
            setVideoRef: setVideoRef,
        };
    },
    props: {
        /**
         * url/path to media
         */
        media: {
            type: String,
            required: true
        },
        /**
         * Background type
         * Background can be an image, a video, an iframe or a color
         * In case of VIDEO, the type is the codec (es: mp4)
         * In case of CSS, it an image that will be used on background-image
         */
        type: {
            type: String,
            default: () => 'image'
        },
        /**
         * When height & width are fixed
         */
        height: {
            type: String,
            required: false
        },
        width: {
            type: String,
            required: false
        },
        /**
         * If the thumbnail and lazy are set,
         * we are gonna use the thumbnail and lazyload the correct media later
         *
         * If lazyload is set but thumbnail not: native lazyload (image only)
         *
         * Otherwise, it's the video's poster
         */
        thumbnail: {
            type: String,
            required: false
        },
        /**
         * Activate lazyload.
         */
        lazy: {
            type: Boolean,
            default: () => false
        },
        /**
         * Class that will be set after
         * a successful lazyload
         */
        loadedClass: {
            type: String,
            default: () => 'loaded'
        },
        /**
         * TODO ratio of media
         * (if only 1 or less fixed width/height)
         */
        ratio: {
            type: String,
            required: false
        },
        /**
         * Title TAG
         */
        title: {
            type: String,
            default: () => ''
        },
        /**
         * Alt TAG
         */
        alt: {
            type: String,
            default: () => ''
        }
    },
});
const __VLS_component = (await import('vue')).defineComponent({
    setup() {
        return {};
    },
    props: {
        /**
         * url/path to media
         */
        media: {
            type: String,
            required: true
        },
        /**
         * Background type
         * Background can be an image, a video, an iframe or a color
         * In case of VIDEO, the type is the codec (es: mp4)
         * In case of CSS, it an image that will be used on background-image
         */
        type: {
            type: String,
            default: () => 'image'
        },
        /**
         * When height & width are fixed
         */
        height: {
            type: String,
            required: false
        },
        width: {
            type: String,
            required: false
        },
        /**
         * If the thumbnail and lazy are set,
         * we are gonna use the thumbnail and lazyload the correct media later
         *
         * If lazyload is set but thumbnail not: native lazyload (image only)
         *
         * Otherwise, it's the video's poster
         */
        thumbnail: {
            type: String,
            required: false
        },
        /**
         * Activate lazyload.
         */
        lazy: {
            type: Boolean,
            default: () => false
        },
        /**
         * Class that will be set after
         * a successful lazyload
         */
        loadedClass: {
            type: String,
            default: () => 'loaded'
        },
        /**
         * TODO ratio of media
         * (if only 1 or less fixed width/height)
         */
        ratio: {
            type: String,
            required: false
        },
        /**
         * Title TAG
         */
        title: {
            type: String,
            default: () => ''
        },
        /**
         * Alt TAG
         */
        alt: {
            type: String,
            default: () => ''
        }
    },
});
export default {};
;
