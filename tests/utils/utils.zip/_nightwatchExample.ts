/**
 * WARNING: EXAMPLE ONLY
 * Do not execute
 */
import { NightwatchBrowser } from 'nightwatch';
import nightwatchCheckRules from './nightwatchCheckRules';

describe('EXAMPLE (don\'t do) E2E Tests - based on the documentation, page /path/on/documentation.html', function () {

  /**
   * Open page
   */
  before(function (browser: NightwatchBrowser, done: () => void) {
    return browser
      .url(process.env.VUE_APP_BASE_URL + '/path/on/documentation.html')
      .waitForElementVisible('custom-css-selector', 10000)
      .perform(() => done());
  });


  /**
   * Utilities
   */
  browser
    .waitForElementVisible('body', 1000)
    .execute(function () {
      // WARNING: This happens in the browser context, not visible from the tests
      // (example: console.log() not happening)
    }, [], function(result) {
      // This happens in the node context (in the tests)
    })
    .pause(200)  // Optional: Pause to allow scrolling to finish
    .end()


  /**
   * Check all listed rules for every custom-css-selector,
   * based on the index of the element
   */
  it('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', async (browser : NightwatchBrowser) =>
    nightwatchCheckRules(browser, 'custom-css-selector', [
      {
        paddingBottom: "664px",
        height: 664,
        width: 664,
        style: "--aspect-ratio: 100%;",
      },
      {
        paddingBottom: "373.5px",
        height: 374,
        width: 664,
        style: "--aspect-ratio: 56.25%;",
      },
    ])
  );

  it('bbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', async (browser : NightwatchBrowser) =>
    nightwatchCheckRules(browser, '.dev-section > *', {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      3: {
        paddingBottom: "664px",
        height: 664,
        width: 664,
        style: "--aspect-ratio: 100%;",
      },
      // eslint-disable-next-line @typescript-eslint/naming-convention
      4: {
        paddingBottom: "373.5px",
        height: 374,
        width: 664,
        style: "--aspect-ratio: 56.25%;",
      },
    })
  );

  /**
   *
   */
  it('ccccccccccccccccccccccccccc', (browser: NightwatchBrowser) => {
    return browser
      .waitForElementVisible('custom-css-selector:nth-of-type(1)', 'Element is visible')
      .getElementSize("custom-css-selector:nth-of-type(1)", (result) => {
        const { height, width } = result.value as { height: number; width: number };
        browser.assert.equal(height, 664, "Correct property: height");
        browser.assert.equal(width, 664, "Correct property: width");
      })
      // .getCssProperty('custom-css-selector:nth-of-type(1)', 'padding-bottom', (result) =>
      //   browser.assert.equal(result.value, "664px", "Correct property: padding-bottom"))
      .assert.cssProperty('custom-css-selector:nth-of-type(1)', 'padding-bottom', '664px', 'Correct property: padding-bottom')
      .assert.attributeContains("custom-css-selector:nth-of-type(1)", "style", "--aspect-ratio: 100%", "Correct property: --aspect-ratio")
      .assert.elementPresent('custom-css-selector:nth-of-type(1) img', 'Correct content: img child')
  });

  /**
   *
   */
  it('ddddddddddddddddddddddddddddddd', async (browser : NightwatchBrowser) => {
    /**
     * Rules for every
     */
    const rules = [
      {
        paddingBottom: "664px",
        height: 664,
        width: 664,
        style: "--aspect-ratio: 100%;",
        content: "img",
      },
      {
        paddingBottom: "373.5px",
        height: 374,
        width: 664,
        style: "--aspect-ratio: 56.25%;",
        content: "img",
      },
    ];

    /**
     * Check every rule based on the index of the element
     */
    return browser
      .element.findAll("custom-css-selector").then((results) =>
        results.forEach((item, index) => {
          const itemElement = element(item);
          itemElement.getRect()
            .then(({ height, width }) => {
              browser.assert.equal(height, rules[index].height, "Correct property: height");
              browser.assert.equal(width, rules[index].width, "Correct property: width");
            })
          itemElement
            .getAttribute('style')
            .then((value) =>
              browser.assert.equal(value, rules[index].style, "Correct attribute: style")
            )
          itemElement
            .getCssValue('padding-bottom')
            .then((value) =>
              browser.assert.equal(value, rules[index].paddingBottom, "Correct css: padding-bottom")
            )
          itemElement.findElement(rules[index].content)
            .then((childElement) => childElement.isDisplayed())
            .then((value) => browser.assert.ok(value, "Correct content"))
        })
      );
  });

  /**
   * Close page
   */
  after(function (browser: NightwatchBrowser) {
    browser.end();
  });
});
